# Team: LIQUIDATORS
**Institution:** Shahjalal University of Science and Technology

## Members
1. **Sajid Zakaria**
   - Email: sajidzakaria1410@gmail.com

2. **Mufassir Chowdhury**
   - Email: mac22214u@gmail.com

3. **Muhammed Fahim**
   - Email: fahim.cse121@gmail.com